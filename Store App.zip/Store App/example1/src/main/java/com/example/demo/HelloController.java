package com.example.demo;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.domain.User;
import com.example.demo.exceptionhandler.EntityNotFoundException;

@RestController
public class HelloController {

	
	 @GetMapping("/helloworld")
	 public String hello() {
		 
		  return "Hello World !!";
	 }
	 
	 @GetMapping("/users/{userId}")
	 public User getUser(@PathVariable("userId") Integer userId) {
		User user = Arrays.asList(
				 
			 		new User(1, "Anup", 32),
			 		new User(2, "Amruta", 31),
			 		new User(3, "Apurva", 28)
			 ).stream().filter(u -> u.getId() == userId).findAny().orElse(null);
		 
		 if(user == null) {
			 throw new EntityNotFoundException("User Not found with ID:"+userId);
		 }
		 return user;
	 }
	 
	 @GetMapping("/users")
	 public List<User> getAllUsers(){
		 return Arrays.asList(
				 
				 		new User(1, "Anup", 32),
				 		new User(2, "Amruta", 31),
				 		new User(3, "Apurva", 28)
				 );
	 }
}
