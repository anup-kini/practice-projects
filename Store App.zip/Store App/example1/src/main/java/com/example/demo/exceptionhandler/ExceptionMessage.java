package com.example.demo.exceptionhandler;

import java.time.LocalDateTime;

public class ExceptionMessage {

	private String message;
	private LocalDateTime dateTime;
	private String referenceLink;
	
	public ExceptionMessage() {
		// TODO Auto-generated constructor stub
	}
	
	public ExceptionMessage(String message, LocalDateTime dateTime, String referenceLink) {
		super();
		this.message = message;
		this.dateTime = LocalDateTime.now();
		this.referenceLink = referenceLink;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public LocalDateTime getDateTime() {
		return dateTime;
	}

	public void setDateTime(LocalDateTime dateTime) {
		this.dateTime = dateTime;
	}

	public String getReferenceLink() {
		return referenceLink;
	}

	public void setReferenceLink(String referenceLink) {
		this.referenceLink = referenceLink;
	}
	
	
}
