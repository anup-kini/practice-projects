package com.flowable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlowableSpringBootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
