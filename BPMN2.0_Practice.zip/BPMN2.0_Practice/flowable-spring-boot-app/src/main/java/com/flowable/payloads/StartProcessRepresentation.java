package com.flowable.payloads;

public class StartProcessRepresentation {

	private String assignee;

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}
}