package com.example.demo.exceptionhandler;

public class EntityNotFoundException extends RuntimeException {

	private String message;

	public EntityNotFoundException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
}
